											2025.08.22 

SampleDataFiles フォルダは，「手を動かしながらやさしく学べるはじめてのAIデータサイエンスリテラシー」の教材が納められています．以下のフォルダとファイルから構成されます．

SampleDataFiles
├── Readme.txt			#本ファイル
├── Chapter_1_Data		#第1章 Wolfram言語の世界を体験してみよう
│   ├── cat1.jpg				#画像サンプルデータ
│   ├── cat2.jpg
│   ├── cat3.jpg
│   ├── cat4.jpg
│   └── cat5.jpg
├── Chapter_2_Data		#第2章 プログラミングの基礎
│   └── sampleimage.jpg				#画像サンプルデータ
├── Chapter_3_Data		#第3章 画像データから見える世界
│   ├── animals.jpg				#実習用画像サンプルデータ
│   ├── automobiles.jpg
│   ├── girl.jpg
│   ├── person.jpg
│   ├── twocats.jpg
│   └── videosample.mp4
├── Chapter_4_Data		#第4章 音・音声データから見える世界
│   └── car.mp3					#実習用音声サンプルデータ
├── Chapter_5_Data		#第5章 AIのしくみ
│   ├── 5-4-snacks-sample			#お菓子の画像データ
│   │   ├── kinoko				#きのこの山画像データ
│   │   │   ├── kinoko1.jpg
│   │   │   ├── kinoko10.jpg
│   │   │   ├── kinoko2.jpg
│   │   │   ├── kinoko3.jpg
│   │   │   ├── kinoko4.jpg
│   │   │   ├── kinoko5.jpg
│   │   │   ├── kinoko6.jpg
│   │   │   ├── kinoko7.jpg
│   │   │   ├── kinoko8.jpg
│   │   │   └── kinoko9.jpg
│   │   └── takenoko				#たけのこの里画像データ
│   │       ├── take1.jpg
│   │       ├── take10.jpg
│   │       ├── take2.jpg
│   │       ├── take3.jpg
│   │       ├── take4.jpg
│   │       ├── take5.jpg
│   │       ├── take6.jpg
│   │       ├── take7.jpg
│   │       ├── take8.jpg
│   │       └── take9.jpg
│   └── 5-6-animals-sample			#動物画像データ
│       ├── cats				#猫の画像
│       │   ├── cat1.jpg
│       │   ├── cat10.jpg
│       │   ├── cat2.jpg
│       │   ├── cat3.jpg
│       │   ├── cat4.jpg
│       │   ├── cat5.jpg
│       │   ├── cat6.jpg
│       │   ├── cat7.jpg
│       │   ├── cat8.jpg
│       │   └── cat9.jpg
│       ├── dogs				#犬の画像
│       │   ├── dog1.jpg
│       │   ├── dog10.jpg
│       │   ├── dog2.jpg
│       │   ├── dog3.jpg
│       │   ├── dog4.jpg
│       │   ├── dog5.jpg
│       │   ├── dog6.jpg
│       │   ├── dog7.jpg
│       │   ├── dog8.jpg
│       │   └── dog9.jpg
│       └── tigers				#虎の画像
│           ├── tiger1.jpg
│           ├── tiger10.jpg
│           ├── tiger2.jpg
│           ├── tiger3.jpg
│           ├── tiger4.jpg
│           ├── tiger5.jpg
│           ├── tiger6.jpg
│           ├── tiger7.jpg
│           ├── tiger8.jpg
│           └── tiger9.jpg
├── Chapter_6_Data		#第6章 テキストデータから見える世界
│   ├── hashire_morph.txt			#走れメロス形態素解析済みテキスト
│   ├── hashire_nosw.txt			#走れメロスストップワード除去テキスト
│   └── hashire_wakachi.txt			#走れメロス分かち書きのみテキスト
├── Chapte_7_Data		#第7章 統計学の基礎
│   └── testsampledata.xls			#統計サンプルデータ
├── Practice_4_Data		#実践編4 動物の鳴き声を機械学習でグループ分けしてみよう
│   ├── birds					#鳥の鳴き声
│   │   ├── birds1.mp3
│   │   ├── birds10.mp3
│   │   ├── birds2.mp3
│   │   ├── birds3.mp3
│   │   ├── birds4.mp3
│   │   ├── birds5.mp3
│   │   ├── birds6.mp3
│   │   ├── birds7.mp3
│   │   ├── birds8.mp3
│   │   └── birds9.mp3
│   ├── cats					#猫の鳴き声
│   │   ├── cats1.mp3
│   │   ├── cats10.mp3
│   │   ├── cats2.mp3
│   │   ├── cats3.mp3
│   │   ├── cats4.mp3
│   │   ├── cats5.mp3
│   │   ├── cats6.mp3
│   │   ├── cats7.mp3
│   │   ├── cats8.mp3
│   │   └── cats9.mp3
│   └── cows					#牛の鳴き声
│       ├── cows1.mp3
│       ├── cows10.mp3
│       ├── cows2.mp3
│       ├── cows3.mp3
│       ├── cows4.mp3
│       ├── cows5.mp3
│       ├── cows6.mp3
│       ├── cows7.mp3
│       ├── cows8.mp3
│       └── cows9.mp3
└── Practice_5_Data		#実践編5 文学作品のイメージに合うデータを可視化しよう
    ├── genjiKiritsubo_morph.txt		#源氏物語桐壺(形態素解析済みテキスト）
    ├── genjiYugao_morph.txt			#源氏物語夕顔
    ├── hahawotazunete_morph.txt		#母を訪ねて三千里
    ├── hashire_morph.txt			#走れメロス
    ├── midaregami_morph.txt			#乱れ髪
    ├── minikui_morph.txt			#みにくいあひるの子
    ├── ningenShikkaku_morph.txt		#人間失格
    ├── shirayukihime_morph.txt			#白雪姫
    ├── tangled_morph.txt			#ラプンツェル
    ├── wagahai_morph.txt			#吾輩は猫である
    └── wakakusa_morph.txt			#若草物語

20 directories, 109 files
